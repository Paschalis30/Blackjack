package com.paschalis.blackjack;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Betting {
static List<Player>players=new ArrayList<Player>(200);
	Player Dealer=new Player("Dealer");
	Scanner input=new Scanner(System.in);
	static int answerBet1;
	 int answerBet;
static int i=0;

static List<Integer>bet=new ArrayList<Integer>(200);
	public void Playersbet(List<Player>players,Player Dealer) {
		
		
		do{
			
		System.out.println(players.get(i).name + " give your amount of bet:");
		answerBet = input.nextInt();
		System.out.println("");
		System.out.println(players.get(i).name + " :your bet is :" + answerBet + "euro");
		bet.add(answerBet);
		
		
		i++;
		}
		while(i<players.size());
		
		
		
		System.out.println("Dealer give your amount of bet:");
		answerBet1 = input.nextInt();
		System.out.println("");

		
		System.out.println("");
		System.out.println(Dealer.name+":your bet is :" + answerBet1 + "euro");
		System.out.println("");
		
	}
	
		
		
	
	public void returnBetDealer() {
		System.out.println(Dealer.name+" you won: "+answerBet1);
	}
	}

