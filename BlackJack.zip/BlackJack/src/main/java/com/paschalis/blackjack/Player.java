package com.paschalis.blackjack;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Scanner;

import org.apache.commons.lang3.ArrayUtils;

public class Player {
	Scanner input = new Scanner(System.in);
Deck deck=new Deck();
	int j = 1;
	String name;
	ArrayList<String> cardsPlayer = new ArrayList<String>(200);
	ArrayList<String> cardsDealer = new ArrayList<String>(200);

	int valuePlayer;
	int valueDealer;
	int valuePlayer1;
	int valueDealer1;
	Cards card = new Cards();
	List<Player>players=new ArrayList<Player>();
	
	public Player(String name) {

		this.name = name;
	}

	int sum;
	int[] value;
	
	public void getNumberOfPlayers(List<Player>players) {
		
		int answerNumberofPlayers=input.nextInt();
		for(int i=0;i<=answerNumberofPlayers;i++) {
			
			System.out.println("Player "+answerNumberofPlayers+" write your name");
			String name=input.next();
		Player client=new Player(name);
		System.out.println("Player your name is: "+client.name);
		players.add(client);
			answerNumberofPlayers--;
		}
	}

	public int getCards(ArrayList<String> cardsPlayer, int valuePlayer, List<String> list) {

		deck.remainingCards();
		System.out.println("");

		// get 2 cards
		// card.shuffleCards();
		cardsPlayer.add(deck.list.get(0));

		cardsPlayer.add(deck.list.get(1));
		deck.list.remove(0);

		deck.list.remove(0);
		System.out.println(name + " " + ": you have the Cards" + cardsPlayer);

		System.out.println("");

		valuePlayer1 = card.getValue(cardsPlayer, valuePlayer, deck.list);

		// valuePlayer=Arrays.stream(sumValue).sum();
		System.out.println("Your current score is: " + valuePlayer1);

		if (valuePlayer1 > 21) {
			System.out.println(name + " :You lost");

		}
		// else {
		System.out.println("");
		deck.remainingCards();
		
		System.out.println(name + " " + ":Do you want to get two more Cards?Y,N");
		

		String answer = input.next();
		if (answer.equalsIgnoreCase("n")) {
			System.out.println("Your play ends here");
		} else {

			// get 1 card
			do {

				cardsPlayer.add(deck.list.get(0));
				deck.list.remove(0);
				System.out.println("");
				System.out.println(name + " " + ":you have the Cards" + cardsPlayer);

				valuePlayer = 0;
				valuePlayer1 = card.getValue(cardsPlayer, valuePlayer, deck.list);
				System.out.println("");
				System.out.println("Your current score is: " + valuePlayer1);
				if (valuePlayer1 > 21) {
					System.out.println(name + ":You lost");
					break;

				}
				

				System.out.println(deck.list);
				System.out.println(name + " " + ":Do you want to get two more Cards?Y,N");
				String answer1 = input.next();
				if (answer1.equalsIgnoreCase("n")) {
					break;
				}

			}

			while (answer.equalsIgnoreCase("y"));
		}

		list = deck.list;// }

		return valuePlayer1;
	}
}
