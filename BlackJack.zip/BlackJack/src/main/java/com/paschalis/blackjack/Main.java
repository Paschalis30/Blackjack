package com.paschalis.blackjack;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		Scanner input=new Scanner(System.in);	
Deck deck=new Deck();
Player pl=new Player("");
		int valuePlayer = 0;
		int valueDealer = 0;
		
		ArrayList<String> cardsPlayer = new ArrayList<String>(200);
		ArrayList<String> cardsDealer = new ArrayList<String>(200);
		List<Player>players=new ArrayList<Player>(200);
		Cards cards = new Cards();
		Betting betting=new Betting();
		Player Dealer=new Player("Dealer");
		 

		String answer;
		System.out.println("**************************");
		System.out.println("WELCOME TO BALCKJACK GAME");
		System.out.println("**************************");
		System.out.println("Choose the number of Players from 1 until 7");
		
		pl.getNumberOfPlayers(players);
		
		
		deck.shuffleCards();
	
		betting.Playersbet(players, Dealer);
		
		
		int j=0;
		while(j<players.size()) {
			valuePlayer=0;
			valueDealer=0;
		System.out.println(players.get(j).name+" is Your Turn!!!");
		System.out.println("");

		valuePlayer = players.get(j).getCards(cardsPlayer, valuePlayer, deck.list);
		System.out.println(players.get(j).name + ":Your current score is:" + valuePlayer);
		System.out.println("");
		//
		if (valuePlayer > 21) {

			System.out.println("Dealer won the Game,because you have more than 21 points");
		    betting.returnBetDealer();
		}

		else {

			System.out.println("Dealer is Your Turn!!!");
			System.out.println("");
			valueDealer = Dealer.getCards(cardsDealer, valueDealer, deck.list);
			System.out.println("");
			System.out.println("Dealer your Current Score is:" + valueDealer);
			//
			if (valueDealer > 21) {
				System.out.println("Dealer, "+players.get(j).name + " won the Game,because you have more than 21 points");
                
				System.out.println(players.get(j).name +" you won: "+betting.bet.get(j));
			}
			else {

				if (valuePlayer > valueDealer) {
					System.out.println(players.get(j).name + ":You won the Game.Congratulations!!!");
					System.out.println(players.get(j).name +" you won: "+betting.bet.get(j));
				} else if (valuePlayer < valueDealer) {
					System.out.println("Dealer:You won the Game.Congratulations!!!");
					betting.returnBetDealer();
				} else if (valuePlayer == valueDealer) {
					System.out.println("Noone was won the game!!!");
				}
			}

			/*
			 * cards.shareCards(Client); cards.shuffle(); cards.shareCards(Dealer);
			 */
		}
		
		
		cardsPlayer.removeAll(cardsPlayer);
		cardsDealer.removeAll(cardsDealer);
		
		j++;}
	}
}
