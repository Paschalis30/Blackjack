package com.paschalis.blackjack;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class Deck {
	
	
	static List<String> list = new ArrayList<String>(100);
	{

		list.add("TWO-Koupa");
		list.add("TWO-Mpastouni");
		list.add("TWO-Trifilli");
		list.add("TWO-Karo");
		list.add("THREE-Koupa");
		list.add("THREE-Mpastouni");
		list.add("THREE-Trifilli");
		list.add("THREE-Karo");
		list.add("FOUR-Koupa");
		list.add("FOUR-Mpastouni");
		list.add("FOUR-Trifilli");
		list.add("FOUR-Karo");
		list.add("FIVE-Koupa");
		list.add("FIVE-Mpastouni");
		list.add("FIVE-Trifilli");
		list.add("FIVE-Karo");
		list.add("SIX-Koupa");
		list.add("SIX-Mpastouni");
		list.add("SIX-Trifilli");
		list.add("SIX-Karo");
		list.add("SEVEN-Koupa");
		list.add("SEVEN-Mpastouni");
		list.add("SEVEN-Trifilli");
		list.add("SEVEN-Karo");
		list.add("EIGHT-Koupa");
		list.add("EIGHT-Mpastouni");
		list.add("EIGHT-Trifilli");
		list.add("EIGHT-Karo");
		list.add("NINE-Koupa");
		list.add("NINE-Mpastouni");
		list.add("NINE-Trifilli");
		list.add("NINE-Karo");
		list.add("TEN-Koupa");
		list.add("TEN-Mpastouni");
		list.add("TEN-Trifilli");
		list.add("TEN-Karo");
		list.add("Dama-Koupa");
		list.add("Dama-Mpastouni");
		list.add("Dama-Trifilli");
		list.add("Dama-Karo");
		list.add("Vales-Koupa");
		list.add("Vales-Mpastouni");
		list.add("Vales-Trifilli");
		list.add("Vales-Karo");
		list.add("Rigas-Koupa");
		list.add("Rigas-Mpastouni");
		list.add("Rigas-Trifilli");
		list.add("Rigas-Karo");
		list.add("ACE-Koupa");
		list.add("ACE-Mpastouni");
		list.add("ACE-Trifilli");
		list.add("ACE-Karo");

	}
	
	public void shuffleCards() {

		Collections.shuffle(list);

	}
	public void remainingCards() {
		System.out.println("The List Of remaining Cards" + list);
	}
}
